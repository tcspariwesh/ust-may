export class Media {
  constructor(
    public slug: string,
    public year: number,
    public title: string,
    public synopsis: string,
  ) {
  }
}
