Repo for the blog post: [NestJS unit testing: A how-to guide with examples](https://tomray.dev/nestjs-unit-testing)

## Installation

```bash
$ npm install
```

## Running the unit tests

```bash
$ npm run test
$ npm run test:watch
```
